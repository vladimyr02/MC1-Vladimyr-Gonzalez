
import java.util.*;

public class Definiciones {

	public static void main(String[] args) {
		// Al usuario se le pregunta el angulo
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Digite un angulo en radianes: ");
		double x = sc.nextDouble();
		
		
		double es = (0.5 * Math.pow(10, -8)) * 100;
		int iteraciones = 0;
		int potencia = 0;
		double ea = 100;
		double valor = 0;
		
		do {
			double anterior = valor;
			if(iteraciones % 2 == 0) {
				valor+= Math.pow(x, potencia)/factorial(potencia);
			}else {
				valor-= Math.pow(x, potencia)/factorial(potencia);
			}
			ea=Math.abs((valor-anterior)/valor)*100;
			
			iteraciones++;
			potencia += 2;
		} while (ea >= es);
		System.out.println("Cos(" + x + ") = " + valor);
		System.out.println("Error aproximado relativo porcentual: " + ea + "%");
		System.out.println("Iteraciones: "+iteraciones);
	}
	private static double factorial(int n) {
		double rta=1;
		for (int i = 2; i <= n; i++) {
			rta *=i;
		}
		return rta;
	}

}
