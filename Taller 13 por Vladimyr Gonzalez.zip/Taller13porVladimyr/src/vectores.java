import java.util.*;

public class vectores {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	Scanner sc=new Scanner(System.in);
	
	
	///VECTOR A
	int longitud;
	System.out.println("Ingrese la longitud 'n' del vector A: ");
	longitud=sc.nextInt();
	
	int vectorA[] = new int[longitud];
	for (int i=0; i<longitud; i++) {
		System.out.println("Ingrese el numero: ");
		vectorA[i]=sc.nextInt();
		
	}
	
	///VECTOR B
	int longitud1;
	System.out.println("Ingrese la longitud 'n' del vector B: ");
	longitud1=sc.nextInt();
	
	int vectorB[] = new int[longitud1];
	for (int i=0; i<longitud1; i++) {
		System.out.println("Ingrese el numero: ");
		vectorB[i]=sc.nextInt();
		
	}
	
	///VECTOR C RESULTANTE
	int vectorC[] = new int[longitud];
	for(int i=0; i<longitud;i++) {
		vectorC[i]=vectorA[i]*vectorB[i];
		
	}
	
	///METODO PARA SUMAR LOS ELEMENTOS DEL ARREGLO DEL VECTOR C
	int total=0;
	for(int j=0;j<vectorC.length;j++) {
		total+=vectorC[j];
		
	}
	///IMPRIMIR EL PRODUCTO VECTORIAL
	System.out.println("El producto vectorial total es: "+ total);
	
	}

}
