import java.util.*;

public class matrices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Ingrese el numero de filas de la primera matriz: ");
	int f1 = sc.nextInt();
	System.out.println("Ingrese el numero de columnas de la primera matriz: ");
	int c1 = sc.nextInt();
	System.out.println("Ingrese el numero de filas de la segunda matriz: ");
	int f2 = sc.nextInt();
	System.out.println("Ingrese el numero de columnas de la segunda matriz: ");
	int c2 = sc.nextInt();
	
	System.out.println("---Datos ingresados---");
	System.out.println("-- Matriz 1 de: " + f1 +"x" + c1 + " --");
	System.out.println("-- Matriz 2 de: " + f2 +"x" + c2 + " --");
	System.out.println("----------------------");
	
	if(c1 == f2) {
		int [][]m1 = new int[c1][f1];
		int [][]m2 = new int[c2][f2];
		int [][]mrA = new int [f1][c2];
		int [][]mrB = new int [f1][c2];
		int [][]mrC = new int [f1][c2];
		int [][]mrD = new int [f1][c2];
		
		
		///MATRIZ 1
		System.out.println("-> Comienza matriz 1");
		for (int i = 0; i<f1; i++) {
			for (int j=0; j<c1;j++) {
				System.out.println("Introduce los valores del elemento " + i + ","+j+":");
				m1[i][j]=sc.nextInt();
				
			}
		}
		///IMPRESION MATRIZ 1
		for (int i = 0; i<f1; i++) {
			for (int j=0; j<c1;j++) {
				System.out.print(m1[i][j] + " ");	
			}
			System.out.println("");
		}
		
		
		///MATRIZ 2
		System.out.println("-> Comienza matriz 2");
		for (int i = 0; i<f2; i++) {
			for (int j=0; j<c2;j++) {
				System.out.println("Introduce los valores del elemento " + i + ","+j+":");
				m2[i][j]=sc.nextInt();
						
			}
		}
		///IMPRESION MATRIZ 2
		for (int i = 0; i<f2; i++) {
			for (int j=0; j<c2;j++) {
				System.out.print(m2[i][j] + " ");	
			}
			System.out.println("");
		}
		
		///MATRIZ RESULTANTE 3A
		System.out.println("--- Matriz Resultante 3A ---");
		for (int i=0;i<f1;i++) {
			for(int j=0; j<c2;j++) {
				mrA[i][j]+= 3 * m1[i][j];
				System.out.print(mrA[i][j] + " ");
			}
			System.out.println("");
		}
		
		///MATRIZ RESULTANTE 4B
		System.out.println("--- Matriz Resultante 4B ---");
		for (int i=0;i<f1;i++) {
			for(int j=0; j<c2;j++) {
				mrB[i][j]+= 4 * m2[i][j];
				System.out.print(mrB[i][j] + " ");
			}
			System.out.println("");
		}
		
		///MATRIZ RESULTANTE A+B
		System.out.println("--- Matriz Resultante A+B ---");
		for (int i=0;i<f1;i++) {
			for(int j=0; j<c2;j++) {
				mrC[i][j]+= m1[i][j] + m2[i][j];
				System.out.print(mrC[i][j] + " ");
			}
			System.out.println("");
		}
			
		
		//MATRIZ RESULTANTE BxA
		System.out.println("--- Matriz Resultante BxA ---");
		for (int i=0;i<f1;i++) {
			for(int j=0; j<c2;j++) {
				for(int h=0;h<c1;h++) {
					mrD[i][j]+= m2[i][h]* m1[h][j];
				}
				System.out.print(mrD[i][j] + " ");
				
			}
			System.out.println("");
		}
		
	}else {
		System.out.println("La operacion no se puede realizar");
	}
	

	}

}
