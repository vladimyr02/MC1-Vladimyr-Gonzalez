import java.util.HashSet;
import java.util.Scanner;

public class Taller2cojuntos {
	public static boolean esPrimo(int num){
		  int count = 2;
		  boolean primo=true;
		  while ((primo) && (count!=num)){
		    if (num % count == 0)
		      primo = false;
		    count++;
		  }
		  return primo;
		  }
	public static HashSet<Integer> union(HashSet<Integer> c1, HashSet<Integer> c2)
	{
		HashSet<Integer> rta = new HashSet<>();
		rta.addAll(c1);
		rta.addAll(c2);
		return rta;
	}
	
	public static HashSet<Integer> interseccion(HashSet<Integer> c3, HashSet<Integer> c4)
	{
		HashSet<Integer> rta1 = new HashSet<>();
		for (int l : c3) {
			for (int � : c4) {
				if (l==�)
				{
					rta1.add(l);
				}
			}
		
		}
		return rta1;
	}
	
	public static HashSet<Integer> diferencia(HashSet<Integer> a1, HashSet<Integer> a2)
	{
		HashSet<Integer> rta2 = new HashSet<>();
		for (int elemento : a1) {
			rta2.add(elemento);
			for (int elemento2 : a2) {
				if (elemento==elemento2)
				{
					rta2.remove(elemento);
				}
			}
		}
		return rta2;
	}
	
	public static HashSet<Integer> diferenciaSimetrica(HashSet<Integer> b1, HashSet<Integer> b2)
	{
		HashSet<Integer> rta3 = new HashSet<>();
		HashSet<Integer> temp = new HashSet<>(b1);
		temp.retainAll(b2);
		rta3.addAll(b1);
		rta3.addAll(b2);
		rta3.removeAll(temp);
		
		return rta3;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int iInicio = 1;
		int iFin = 40;
		
		HashSet<Integer> conjuntoA = new HashSet <> ();	
		for (int i=6; i<25;i++ ) {
			conjuntoA.add(i);
		}
			System.out.println("A = " + conjuntoA);
		
		HashSet<Integer> conjuntoB = new HashSet<>();
		for(int i=1; i<=30;i++) {
			if(i%2==1) {
				conjuntoB.add(i);
			}
							
		}
			System.out.println("B = " + conjuntoB);
		
		HashSet<Integer> conjuntoC = new HashSet<>();
			conjuntoC.add(0);
			conjuntoC.add(3);
			conjuntoC.add(6);
			conjuntoC.add(9);
			conjuntoC.add(11);
			conjuntoC.add(15);
			conjuntoC.add(18);
			conjuntoC.add(20);
			
			System.out.println("C = " + conjuntoC);
		
		HashSet<Integer> conjuntoD = new HashSet <> ();	
		for (int i=iInicio;i<=iFin;i++) {
			if (esPrimo(i))
				conjuntoD.add(i);			
		}
			System.out.println("D = " + conjuntoD);
			
			System.out.println("Operacion 1: "+interseccion(diferenciaSimetrica(conjuntoA,conjuntoB),conjuntoC));
			System.out.println("Operacion 2: "+union(diferencia(conjuntoA,conjuntoC),conjuntoB));
			System.out.println("Operacion 3: "+diferenciaSimetrica(conjuntoA,union(conjuntoC,conjuntoD)));
			System.out.println("Operacion 4: "+diferenciaSimetrica(diferencia(conjuntoC,conjuntoA),interseccion(conjuntoB,conjuntoD)));
			//DAR ENTER EN LA CONSOLA PARA QUE CORRA TODO CORRECTAMENTE
	}
	
	

}