import java.util.HashSet;
import java.util.Scanner;


public class Conjustos {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Conjunto A");
		HashSet<Integer> conjuntoA = new HashSet<>();
		
		for (int i = 0; i<5;i++) {
			System.out.print("Un numero: ");
			int aux = sc.nextInt();
			
			conjuntoA.add(aux);
		}
		
		System.out.println("A = " + conjuntoA);
		
		for (int elemento : conjuntoA) {
			System.out.println(elemento);
		}
			
		System.out.println("Conjunto B");
		HashSet<Integer> conjuntoB = new HashSet<>();
			
		for (int i = 0; i<5;i++) {
			System.out.print("Un numero: ");
			int aux = sc.nextInt();
				
			conjuntoB.add(aux);
		}
		System.out.println("B = " + conjuntoB);
		
		System.out.println("¿Que operacion desea realizar con los conjustos?");
		System.out.println("1.Union");
		System.out.println("2.Interseccion");
		System.out.println("3.Diferencia");
		int opcion = sc.nextInt();
		
		switch (opcion) {
			case 1:
				//Union
				HashSet<Integer> conjuntoUnion = new HashSet<>();
				for (int elemento : conjuntoA) {
					conjuntoUnion.add(elemento);
				}
				for (int elemento : conjuntoB) {
					conjuntoUnion.add(elemento);
				}
				System.out.println("A U B = " + conjuntoUnion);
				break;
			case 2:
				//Intersection
				HashSet<Integer> conjuntoInterseccion = new HashSet<>();
				for(int elemento: conjuntoA) {
					for(int elemento2 : conjuntoB) {
						if(elemento==elemento2) {
						conjuntoInterseccion.add(elemento);
						}
					}
				}
				System.out.println("A interseccion B = " + conjuntoInterseccion);
				break;
			case 3:
				//Difference
				HashSet<Integer> conjuntoDiferencia = new HashSet<>();
				for (int elemento : conjuntoA) {
					conjuntoDiferencia.add(elemento);
					for (int elemento2 : conjuntoB) {
						if(elemento==elemento2)
						{
							conjuntoDiferencia.remove(elemento);
						}
					}
				}
				System.out.println("A diferencia B = " + conjuntoDiferencia);
				
				HashSet<Integer> conjuntoDiferencia2 = new HashSet<>();
				for (int elemento3 : conjuntoB) {
					conjuntoDiferencia2.add(elemento3);
					for (int elemento4 : conjuntoA) {
						if(elemento3==elemento4)
						{
							conjuntoDiferencia2.remove(elemento3);
						}
					}
				}
				System.out.println("B diferencia A = " + conjuntoDiferencia2);
				break;
		}
}
}
